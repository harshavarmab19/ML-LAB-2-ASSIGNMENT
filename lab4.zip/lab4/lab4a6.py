import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier

data = pd.read_csv(r"C:\Users\harsh\Downloads\P_DIQ_converted (1).csv")

data = data[data["DIQ010"].isin([1, 2])]
data["DIQ010"] = data["DIQ010"].map({1: 1, 2: 0})

features = ["DIQ160", "DIQ180"]
data = data[["DIQ010"] + features].dropna()

X = data[features].values
y = data["DIQ010"].values

np.random.seed(10)
idx = np.random.choice(len(X), 20, replace=False)
X_train = X[idx]
y_train = y[idx]

plt.figure()
plt.scatter(X_train[y_train == 0, 0],
            X_train[y_train == 0, 1],
            color="blue", label="Class 0")

plt.scatter(X_train[y_train == 1, 0],
            X_train[y_train == 1, 1],
            color="red", label="Class 1")

plt.xlabel(features[0])
plt.ylabel(features[1])
plt.title("A6 – Training Data (Project Dataset)")
plt.legend()
plt.show()

x_min, x_max = X_train[:, 0].min(), X_train[:, 0].max()
y_min, y_max = X_train[:, 1].min(), X_train[:, 1].max()

xx, yy = np.meshgrid(
    np.linspace(x_min, x_max, 100),
    np.linspace(y_min, y_max, 100)
)

X_test = np.c_[xx.ravel(), yy.ravel()]

knn = KNeighborsClassifier(n_neighbors=3)
knn.fit(X_train, y_train)

y_pred = knn.predict(X_test)

plt.figure()
plt.scatter(X_test[y_pred == 0, 0],
            X_test[y_pred == 0, 1],
            color="blue", s=5)

plt.scatter(X_test[y_pred == 1, 0],
            X_test[y_pred == 1, 1],
            color="red", s=5)

plt.scatter(X_train[y_train == 0, 0],
            X_train[y_train == 0, 1],
            color="cyan", edgecolor="black", s=80)

plt.scatter(X_train[y_train == 1, 0],
            X_train[y_train == 1, 1],
            color="orange", edgecolor="black", s=80)

plt.xlabel(features[0])
plt.ylabel(features[1])
plt.title("A6 – kNN Output (k = 3)")
plt.show()

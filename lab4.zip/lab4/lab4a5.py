import numpy as np
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier

np.random.seed(10)

X_train = np.random.randint(1, 11, 20)
Y_train = np.random.randint(1, 11, 20)
y_train = np.where(X_train + Y_train <= 11, 0, 1)

train_data = np.column_stack((X_train, Y_train))

x_vals = np.arange(0, 10.1, 0.1)
y_vals = np.arange(0, 10.1, 0.1)
xx, yy = np.meshgrid(x_vals, y_vals)
X_test = np.c_[xx.ravel(), yy.ravel()]

for k in [1, 3, 5, 7, 9]:
    knn = KNeighborsClassifier(n_neighbors=k)
    knn.fit(train_data, y_train)
    y_pred = knn.predict(X_test)

    plt.figure()
    plt.scatter(X_test[y_pred == 0, 0], X_test[y_pred == 0, 1], color="blue", s=5)
    plt.scatter(X_test[y_pred == 1, 0], X_test[y_pred == 1, 1], color="red", s=5)
    plt.title(f"kNN Classification (k = {k})")
    plt.show()

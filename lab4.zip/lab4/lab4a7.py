import pandas as pd
from sklearn.model_selection import GridSearchCV
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler

data = pd.read_csv(r"C:\Users\harsh\Downloads\P_DIQ_converted (1).csv")

data = data[data["DIQ010"].isin([1, 2])]
data["DIQ010"] = data["DIQ010"].map({1: 1, 2: 0})

features = ["DIQ160", "DIQ180", "DIQ070"]
data = data[["DIQ010"] + features].dropna()

X = data[features]
y = data["DIQ010"]

scaler = StandardScaler()
X = scaler.fit_transform(X)

param_grid = {"n_neighbors": list(range(1, 21))}

knn = KNeighborsClassifier()
grid = GridSearchCV(knn, param_grid, cv=5, scoring="accuracy")
grid.fit(X, y)

print("Best k value:", grid.best_params_["n_neighbors"])
print("Best cross-validation accuracy:", grid.best_score_)

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score, f1_score

#A1
data = pd.read_csv(r"C:\Users\harsh\Downloads\P_DIQ_converted (1).csv")

print("Dataset Columns:")
print(data.columns)

print("\nFirst 5 rows:")
print(data.head())


target_col = "DIQ010"
print(f"\nTarget column detected: {target_col}")


feature_cols = ["DIQ160", "DIQ180", "DIQ070"]

data = data[[target_col] + feature_cols]

data = data[data[target_col].isin([1, 2])]

data[target_col] = data[target_col].map({1: 1, 2: 0})

for col in feature_cols:
    data[col] = data[col].fillna(data[col].mean())


X = data[feature_cols]
y = data[target_col]


X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)


scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)


knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(X_train, y_train)


y_train_pred = knn.predict(X_train)
y_test_pred = knn.predict(X_test)


print("\nTraining Confusion Matrix:")
print(confusion_matrix(y_train, y_train_pred))

print("\nTest Confusion Matrix:")
print(confusion_matrix(y_test, y_test_pred))


print("\nTraining Performance Metrics")
print("Accuracy :", accuracy_score(y_train, y_train_pred))
print("Precision:", precision_score(y_train, y_train_pred))
print("Recall   :", recall_score(y_train, y_train_pred))
print("F1-score :", f1_score(y_train, y_train_pred))

print("\nTest Performance Metrics")
print("Accuracy :", accuracy_score(y_test, y_test_pred))
print("Precision:", precision_score(y_test, y_test_pred))
print("Recall   :", recall_score(y_test, y_test_pred))
print("F1-score :", f1_score(y_test, y_test_pred))


train_f1 = f1_score(y_train, y_train_pred)
test_f1 = f1_score(y_test, y_test_pred)

print("\nModel Learning Outcome:")

if train_f1 - test_f1 > 0.1:
    print("OVERFITTING: High training performance, lower test performance.")
elif abs(train_f1 - test_f1) < 0.05:
    print("REGULAR FITTING: Good generalization.")
else:
    print("UNDERFITTING: Model is too simple.")

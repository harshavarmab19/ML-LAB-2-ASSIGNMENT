import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score


data = pd.read_csv(r"C:\Users\harsh\Downloads\P_DIQ_converted (1).csv")

print("Dataset Columns:")
print(data.columns)


data = data[data["DIQ010"].isin([1, 2])]
data["DIQ010"] = data["DIQ010"].map({1: 1, 2: 0})


X = data[["DIQ160", "DIQ180", "DIQ070"]]
y = data["DIQ010"]


X = X.fillna(X.mean())


X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)


model = LinearRegression()
model.fit(X_train, y_train)


y_train_pred = model.predict(X_train)
y_test_pred = model.predict(X_test)


train_mse = mean_squared_error(y_train, y_train_pred)
test_mse = mean_squared_error(y_test, y_test_pred)

train_rmse = np.sqrt(train_mse)
test_rmse = np.sqrt(test_mse)

train_r2 = r2_score(y_train, y_train_pred)
test_r2 = r2_score(y_test, y_test_pred)


print("\nTraining Data")
print("MSE :", train_mse)
print("RMSE:", train_rmse)
print("R2  :", train_r2)

print("\nTest Data")
print("MSE :", test_mse)
print("RMSE:", test_rmse)
print("R2  :", test_r2)


if abs(train_r2 - test_r2) < 0.05:
    print("\nModel shows regular fitting")
elif train_r2 > test_r2:
    print("\nModel shows overfitting")
else:
    print("\nModel shows underfitting")

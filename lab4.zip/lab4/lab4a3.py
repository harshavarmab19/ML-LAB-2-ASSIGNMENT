import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

np.random.seed(10)

X = np.random.randint(1, 11, 20)
Y = np.random.randint(1, 11, 20)

labels = np.where(X + Y <= 11, 0, 1)

data = pd.DataFrame({"X": X, "Y": Y, "Class": labels})

plt.figure()
plt.scatter(data[data["Class"] == 0]["X"],
            data[data["Class"] == 0]["Y"],
            color="blue", label="Class 0")

plt.scatter(data[data["Class"] == 1]["X"],
            data[data["Class"] == 1]["Y"],
            color="red", label="Class 1")

plt.xlabel("Feature X")
plt.ylabel("Feature Y")
plt.title("Training Data Scatter Plot")
plt.legend()
plt.show()

print(data)
